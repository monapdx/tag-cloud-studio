# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-11-03
- Initial public repo setup (README, LICENSE, .gitignore, contribution docs).