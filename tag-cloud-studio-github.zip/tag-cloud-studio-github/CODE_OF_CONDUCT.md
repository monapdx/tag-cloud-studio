# Contributor Covenant Code of Conduct

We are committed to a friendly, safe, and welcoming environment for all.

## Our Standards
- Be respectful and inclusive.
- Accept constructive criticism with grace.
- Focus on what is best for the community.

## Enforcement
Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by opening an issue or emailing the maintainer.